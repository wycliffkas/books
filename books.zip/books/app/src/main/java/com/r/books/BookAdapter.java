package com.r.books;

import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class BookAdapter extends RecyclerView.Adapter<BookAdapter.BookViewHolder>{

    ArrayList<Book> books;

    public BookAdapter(ArrayList<Book> books){
        this.books = books;

    }

    @Override
    public BookAdapter onCreateViewHolder(ViewGroup parent, int viewType) {
        return null;
    }


    @Override
    public void onBindViewHolder(BookAdapter holder, int position) {

    }

    @Override
    public int getItemCount() {
        return 0;
    }

    public class BookViewHolder extends RecyclerView.ViewHolder {

        TextView title;
        TextView author;
        TextView publisher;
        TextView publishedDate;


        public BookViewHolder(View view) {
            super(view);
            title = view.findViewById(R.id.bookTitle);
            author = view.findViewById(R.id.bookAuthor);
            publisher = view.findViewById(R.id.bookPublisher);
            publishedDate = view.findViewById(R.id.bookPublishedDate);

        }
    }
}
