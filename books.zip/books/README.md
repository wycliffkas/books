### books

An android application that leverages the Google books API to display recently published books

search and browse through the list of books.
view information about a book, including metadata, availability and price.